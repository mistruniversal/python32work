from django.shortcuts import render
from django.template.response import TemplateResponse
# Create your views here.

from django.http import HttpResponse,HttpResponseRedirect,HttpResponsePermanentRedirect


# def homepageview(request):
#     return HttpResponse('Hello world')

# def index(request):
#     return HttpResponse('<h2>лавная старница</h2>')


# def adout(request, name, age):
#     return HttpResponse(f'''
#         <h2>О пользователе</h2>
#         <p>Имя: {name}</p>
#         <p>Возраст: {age}</p>
#     ''')
#
#
# def contact(request):
#     return HttpResponse('<h2>Контакты</h2>')
#
# def user(request, name='Undefined', age=0):
#     return HttpResponse(f'<h1>Моё имя {name} Возраст: {age}</h1>')


"""
FBV - представление с помощью функций.
CBV - представление на основе классов
"""


# def account(request,name="undefinde",age=0):
#     return HttpResponse(f'Имя {name} Возраст {age}')
#
# def home(request):
#     return HttpResponse('<h2>Главная страница</h2>')
#
#
# def massage(request,category='undefinde',subcategory='undefinde',theme='undefinde',numbers=0):
#     return HttpResponse(f'<h2>{category} {subcategory} {theme} {numbers}</h2>')
#
# def user(request):
#     age=request.GET.get('age')
#     name=request.GET.get('age')
#     return HttpResponse(f'<h2>Имя {name} Возраст {age}</h2>')
#
# def support(request):
#     HttpResponseRedirect('contact/')
#
# def about(request):
#     HttpResponsePermanentRedirect('/')



# def index(request):
#     return render(request,'index.html')


# def index(request):
#     return TemplateResponse(request,'index.html')

def index(request):
    data={'header':"aeohaesbu",'message':241}
    return render(request,'index.html',context=data)


