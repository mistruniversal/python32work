from django.urls import path, re_path
from blog import views

# from .views import homepageview

urlpatterns = [
    # path('', views.index, name='home'),
    # re_path(r'^about/contact/', views.contact),
    # re_path(r'^about/', views.adout, kwargs={'name': 'Tom', 'age': '30'}),
    # path('user/<str:name>/<int:age>', views.user),
    # path('user/<str:name>/', views.user),
    # path('user//<int:age>/', views.user),
    # path('user/', views.user),
    # path('about/', views.adout),
    # path('contact/', views.contact),


    # path('', views.home),
    # path('accounts/user_name/user_age/<str:name>/<int:age>',views.account),
    # path('accounts/user_name/<str:name>',views.account),
    # path('accounts/user_age/<int:age>',views.account),
    # path('accounts/',views.account),
    # path('base/<str:category>/<str:subcategory>/<str:theme>/<int:numbers>',views.massage),
    # path('user/',views.user)



    path('',views.index)
]

"""
Параметры представлений
https://127.0.0.1:8000/user/Tom/30
"""
